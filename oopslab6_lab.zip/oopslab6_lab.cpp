//This program does various operations (add, edit and delete) on teacher record

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Staff{
    protected:
        int id;
        string name;
        double basicSalary;
    public:
        void setDetails();
        void getDetails();
        
        int getId() { return id; }
        string getName() { return name; }
        double getBasicSalary() { return basicSalary; }
};

class StaffList{
    public:
        vector<int> Id;
        vector<string> Name;
        vector<double> Salary;
        vector<string> Category;
        void pushToList(int,string,double,string);
        void displayList(); 
};

class TeachStaff : virtual public Staff{
    protected:
        int teachHrs;
    public:
        void setTeachHrs();
        double getBonus();
    TeachStaff(){
        teachHrs=10;
    }
};

class ResearchStaff : virtual public Staff{
    protected:
        int ResearchProj;
    public:
        void setResearchProj();
        double getBonus();
    ResearchStaff(){
        ResearchProj=10;
    }
};

class AdminStaff : virtual public Staff{
    protected:
        int AdminHrs;
    public:
        void setAdminHrs();
        double getBonus();
    AdminStaff(){
        AdminHrs=10;
    }
};

class TeachResearchStaff : public TeachStaff, public ResearchStaff {
    public:
        void setTeachResearchDetails();
        double getBonusTRS();
};

class AdminTeachResearchStaff : public TeachResearchStaff, public AdminStaff {
    public:
        void setAllDetails();
        double getBonusTRAS();
};

int main(){
    int choice;
    StaffList sList;
    
    while (true){
        cout << "\n===============================\n";
        cout << "1. Add Teaching Staff\n";
        cout << "2. Add Research Staff\n";
        cout << "3. Add Admin Staff\n";
        cout << "4. Add Teaching-Research Staff\n";
        cout << "5. Add Admin Teaching-Research Staff\n";
        cout << "6. Display All Staff\n";
        cout << "7. Exit\n";
        cout << "Enter your choice  : ";
        cin >> choice;
        
        if (choice == 7) {
            cout << "Exiting program...\n";
            break;
        }
        
        switch(choice){
            case 1: {
                TeachStaff ts;
                ts.setDetails();
                ts.setTeachHrs();
                sList.pushToList(ts.getId(), ts.getName(), ts.getBasicSalary(), "Teaching");
                break;
            }
            case 2: {
                ResearchStaff rs;
                rs.setDetails();
                rs.setResearchProj();
                sList.pushToList(rs.getId(), rs.getName(), rs.getBasicSalary(), "Research");
                break;
            }
            case 3: {
                AdminStaff as;
                as.setDetails();
                as.setAdminHrs();
                sList.pushToList(as.getId(), as.getName(), as.getBasicSalary(), "Admin");
                break;
            }
            case 4: {
                TeachResearchStaff trs;
                trs.setDetails();
                trs.setTeachResearchDetails();
                sList.pushToList(trs.getId(), trs.getName(), trs.getBasicSalary(), "Teaching-Research");
                break;
            }
            case 5: {
                AdminTeachResearchStaff atrs;
                atrs.setDetails();
                atrs.setAllDetails();
                sList.pushToList(atrs.getId(), atrs.getName(), atrs.getBasicSalary(), "Admin-Teaching-Research");
                break;
            }
            case 6: {
                sList.displayList();
                break;
            }
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    }
    return 0;
}

// --- Member functions Definitions ---

void Staff::setDetails() {
    cout << "Enter ID: "; cin >> id;
    cout << "Enter Name: "; cin >> name;
    cout << "Enter Basic Salary: "; cin >> basicSalary;
}

void Staff::getDetails() {
    cout << "ID: " << id << ", Name: " << name << ", Basic Salary: " << basicSalary << endl;
}

void StaffList::pushToList(int id, string name, double salary, string category){
    Id.push_back(id);
    Name.push_back(name);
    Salary.push_back(salary);
    Category.push_back(category);
}

void StaffList::displayList() {
    if (Id.empty()) {
        cout << "\nNo staff records found.\n";
    }
    cout << "\n--- Staff Records ---\n";
    for (size_t i = 0; i < Id.size(); i++) {
        cout << "ID: " << Id[i] << " | Name: " << Name[i] 
             << " | Base Salary: $" << Salary[i] << " | Role: " << Category[i] << endl;
    }
}

void TeachStaff::setTeachHrs() { 
    cout << "Enter Teaching Hours: "; cin >> teachHrs; 
}
double TeachStaff::getBonus() { 
    int Bonus= (teachHrs * 100);
      basicSalary+=Bonus;
      return Bonus;  
}

void ResearchStaff::setResearchProj() { 
    cout << "Enter Research Projects/Hours: "; cin >> ResearchProj; 
}
double ResearchStaff::getBonus() { 
    int Bonus= (ResearchProj*1000);
      basicSalary+=Bonus;
      return Bonus; 
}

void AdminStaff::setAdminHrs() { 
    cout << "Enter Admin Task Hours: "; cin >> AdminHrs; 
}
double AdminStaff::getBonus() { 
      int Bonus= (AdminHrs * 100);
      basicSalary+=Bonus;
      return Bonus; 
}

double TeachResearchStaff::getBonusTRS(){
      int Bonus= (teachHrs * 100)+(ResearchProj*1000);
      basicSalary+=(teachHrs * 100);
      return Bonus;  
}

void TeachResearchStaff::setTeachResearchDetails() {
    setTeachHrs();
    setResearchProj();
    getBonusTRS();
}

double AdminTeachResearchStaff::getBonusTRAS(){
   int Bonus= (teachHrs * 100)+(ResearchProj*1000)+(AdminHrs*100);
      basicSalary+=(teachHrs * 100);
      return Bonus;   
}

void AdminTeachResearchStaff::setAllDetails() {
    setTeachHrs();
    setResearchProj();
    setAdminHrs();
}